from django.contrib import admin
from .models import BlogPost

@admin.register(BlogPost)
class BlogPostAdmin(admin.ModelAdmin):
    """自定义博客帖子管理界面"""
    list_display = ('title', 'owner', 'date_added', 'text_preview')
    list_filter = ('date_added', 'owner')
    search_fields = ('title', 'text')
    date_hierarchy = 'date_added'
    ordering = ('-date_added',)
    
    def text_preview(self, obj):
        """显示文本预览"""
        return obj.text[:50] + '...' if len(obj.text) > 50 else obj.text
    text_preview.short_description = '内容预览'