from django import forms
from .models import BlogPost

class BlogPostForm(forms.ModelForm):
    """创建和编辑博客帖子的表单"""
    class Meta:
        model = BlogPost
        fields = ['title', 'text']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入标题'
            }),
            'text': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 10,
                'placeholder': '请输入内容'
            }),
        }
        labels = {
            'title': '标题',
            'text': '内容',
        }