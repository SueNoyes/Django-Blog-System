from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class BlogPost(models.Model):
    """博客帖子模型"""
    title = models.CharField(max_length=200, verbose_name="标题")
    # 为19-5添加用户关联
    owner = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="作者")
    text = models.TextField(verbose_name="内容")
    date_added = models.DateTimeField(default=timezone.now, verbose_name="添加日期")
    
    class Meta:
        verbose_name = "博客帖子"
        verbose_name_plural = "博客帖子"
        ordering = ['-date_added']  # 按添加日期倒序排列
    
    def __str__(self):
        """返回模型的字符串表示"""
        return self.title
    
    def get_absolute_url(self):
        """返回帖子的URL"""
        from django.urls import reverse
        return reverse('blogs:post_detail', args=[str(self.id)])