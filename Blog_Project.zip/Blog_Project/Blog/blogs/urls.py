from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = 'blogs'

urlpatterns = [
    # 主页
    path('', views.index, name='index'),
    
    # 帖子详情
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    
    # 创建新帖子
    path('new/', views.new_post, name='new_post'),
    
    # 编辑帖子
    path('edit/<int:pk>/', views.edit_post, name='edit_post'),
    
    # 认证相关（19-5要求）
    path('accounts/login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(template_name='registration/logout.html'), name='logout'),
    path('accounts/signup/', views.SignUpView.as_view(), name='signup'),
]