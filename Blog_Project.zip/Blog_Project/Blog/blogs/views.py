from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.urls import reverse_lazy
from django.views.generic import CreateView
from .models import BlogPost
from .forms import BlogPostForm

def index(request):
    """显示所有博客帖子"""
    posts = BlogPost.objects.all().order_by('-date_added')
    context = {'posts': posts}
    return render(request, 'blogs/index.html', context)

def post_detail(request, pk):
    """显示单个博客帖子详情"""
    post = get_object_or_404(BlogPost, pk=pk)
    context = {'post': post}
    return render(request, 'blogs/post_detail.html', context)

@login_required
def new_post(request):
    """添加新帖子"""
    if request.method != 'POST':
        # 未提交数据：创建一个新表单
        form = BlogPostForm()
    else:
        # POST提交的数据：对数据进行处理
        form = BlogPostForm(data=request.POST)
        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.owner = request.user  # 设置帖子作者为当前用户
            new_post.save()
            messages.success(request, '帖子已成功发布！')
            return redirect('blogs:index')
    
    context = {'form': form}
    return render(request, 'blogs/new_post.html', context)

@login_required
def edit_post(request, pk):
    """编辑既有帖子"""
    post = get_object_or_404(BlogPost, pk=pk)
    
    # 检查用户是否是该帖子的作者（19-5要求）
    if post.owner != request.user:
        messages.error(request, '您只能编辑自己的帖子！')
        return redirect('blogs:index')
    
    if request.method != 'POST':
        # 初次请求：使用当前帖子填充表单
        form = BlogPostForm(instance=post)
    else:
        # POST提交的数据：对数据进行处理
        form = BlogPostForm(instance=post, data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '帖子已成功更新！')
            return redirect('blogs:index')
    
    context = {'form': form, 'post': post}
    return render(request, 'blogs/edit_post.html', context)

# 用户注册视图
class SignUpView(CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('blogs:index')
    template_name = 'registration/signup.html'
    
    def form_valid(self, form):
        response = super().form_valid(form)
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password1')
        user = authenticate(username=username, password=password)
        login(self.request, user)
        messages.success(self.request, f'欢迎 {username}！')
        return response